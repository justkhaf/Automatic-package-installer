clear
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
echo
toilet -f big -F gay Khafi
echo $green "WELLCOME"
echo "========================================" |lolcat
echo
echo $red"Automatic Installation"
echo "created by :-IG:@kahfimckenzie"
echo "            -Fb:Kim kenzie Park"
echo "            -Yt: For Moonlight"
echo "=======================================" |lolcat
echo
echo $green
echo "1.) Pkg update && pkg upgrade "
echo "2.) pkg install nano "
echo "3.) pkg install ruby"
echo "4.) pkg install figlet"
echo "5.) pkg install toilet"
echo "6.) pkg install bash"
echo "7.) pkg install git"
echo "8.) pkg install python(1.2.3)"
echo "9.) pkg install php"
echo "10.)pkg install curl"
echo "11.)pkg install wget"
echo "12.)pkg install jq"
read -p "Install semua package (Y/n) = " bro

if [ $bro = N ] || [ $bro = n ]
then 
clear
exit 
fi

if [ $bro = Y ] || [ $bro = y ]
then
clear
echo
toilet -f big -F gay Khaf
echo $green"Sedang menginstall pkg update && pkg upgrade"
sleep 2
pkg update && upgrade
fi
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
echo
toilet -f big -F gay Khaf
echo $green"Sedang menginstall Nano "
sleep 2
pkg install nano
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green"Sedang menginstall Ruby"
sleep 2
pkg install ruby
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
echo
toilet -f big -F gay Khaf
echo $green"Sedang menginstall Figlet"
pkg install figlet
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green"Sedang menginstall toilet"
pkg install toilet
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green"sedang menginstall Git"
pkg install git
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green" Sedang menginstall bash"
pkg install bash
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green"Sedang menginstall python"
pkg install python
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green"Sedang menginstall python 2"
pkg install python2
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green"Sedang menginstall python 3"
pkg install python3
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green"Sedang menginstall curl"
pkg install curl
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green"Sedang menginstall php"
pkg install php
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green"Sedang menginstall Wget"
pkg install wget
echo $green"Penginstallan paket selesai✓"
sleep 2
clear
toilet -f big -F gay Khaf
echo $green"Sedang menginstall JQ"
pkg install jq
echo $green"Penginstallan paket selesai✓"
sleep 2

